﻿namespace Exercice_5___Classes
{
    public enum EmployeeStatus
    {
        Permanent,
        Occasional,
        Contractual
    }
}
