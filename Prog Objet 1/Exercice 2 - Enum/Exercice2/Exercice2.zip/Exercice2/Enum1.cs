﻿namespace Exercice2
{
    public enum BloodType
    {
        A,
        B,
        AB,
        O
    }
}
