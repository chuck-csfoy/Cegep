﻿// PROF : le fichier devrait avoir le même nom que l'enum.
namespace Exercice2
{
    public enum BloodType
    {
        A,
        B,
        AB,
        O
    }
}
