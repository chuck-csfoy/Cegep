const formulaireInscription = document.getElementById("formulaireInscription");

const presenceEmployeOui = document.getElementById("oui")
const presenceEmployeNon = document.getElementById("non")

const choixRepasEmploye1 = document.getElementById("choixRepasEmploye1");
const choixRepasEmploye2 = document.getElementById("choixRepasEmploye2");

const traineau = document.getElementById("traineau");
const noelDisco = document.getElementById("noelDisco");
const karaoke = document.getElementById("karaoke");
const glissades = document.getElementById("glissades");
const laserTag = document.getElementById("laserTag");
const casino = document.getElementById("casino");

const checkbox1 = document.getElementById("checkbox1");
const checkbox2 = document.getElementById("checkbox2");


const messageErreur = document.getElementById("messageErreur");

formulaireInscription.onsubmit = ValiderFormulaire;




function {
    choixRepasEmploye1.classList.remove('d-none');
    choixRepasEmploye2.classList.remove('d-none');
}


function {
    choixRepasEmploye1.classList.add('d-none');
    choixRepasEmploye2.classList.add('d-none');
}

presenceEmployeNon.addEventListener('click', showRepas);
presenceEmployeOui.addEventListener('click', hideRepas);

function ValiderPresenceEmploye()
{
    let isPresenceValid = false;

    if (presenceEmployeOui.checked === true)
    {
        isPresenceValid = true;
    }
    else if (presenceEmployeNon.checked === true)
    {
        isPresenceValid = true;
    }
    else
    {
        messageErreur.textContent += 'Vous devez confirmer votre présence!'
    }
    return isPresenceValid;
}

function ValiderCheckbox()
{
    let cptChecked = 0;
    
    if (traineau.checked)
    {
        cptChecked++;
    }
    if (noelDisco.checked)
    {
        cptChecked++;
    }
    if (karaoke.checked)
    {
        cptChecked++;
    }
    if (glissades.checked)
    {
        cptChecked++;
    }
    if (laserTag.checked)
    {
        cptChecked++;
    }
    if (casino.checked)
    {
        cptChecked++;
    } 
    
    if (cptChecked === 2)
    {
        traineau.classList.remove('border-danger');
        noelDisco.classList.remove('border-danger');
        karaoke.classList.remove('border-danger');
        glissades.classList.remove('border-danger');
        laserTag.classList.remove('border-danger');
        casino.classList.remove('border-danger');
    }
    else
    {
        traineau .classList.add('border-danger');
        noelDiscoclassList.add('border-danger');
        karaoke.classList.add('border-danger');
        glissades.classList.add('border-danger');
        laserTag.classList.add('border-danger');
        casino.classList.add('border-danger');
        messageErreur.textContent += 'Veuillez cocher deux choix!'
    }
    return cptChecked ;
}

function ValiderFormulaire(evenement) 
{
    let nbChampsInvalides = 0;

    if (!ValiderPresenceEmploye())
    {
        ++nbChampsInvalides;
    }

    if (!ValiderCheckbox()) 
    {
        ++nbChampsInvalides;
    }

    if (nbChampsInvalides !== 0) 
    {
        messageErreur.classList.remove('d-none');
        evenement.preventDefault();
    }

    else 
    {
        messageErreur.classList.add('d-none');
        alert('Formulaire envoyé')
    }
}

// const formulaireInscription = document.getElementById("formulaireInscription");
// const motDePasse = document.getElementById("motDePasse");
// const confirmationMotDePasse = document.getElementById('confirmation')
// const messageErreur = document.getElementById("messageErreur");
// const voirMotDePasse = document.getElementById("voirMotDePasse");

// formulaireInscription.onsubmit = ValiderFormulaire;
// voirMotDePasse.onchange = BasculerMotDePasse;

// function BasculerMotDePasse() {
//     if (voirMotDePasse.checked === true) {
//         motDePasse.type = "text";
//         confirmationMotDePasse.type = "text";
//     } else {
//         motDePasse.type = "password";
//         confirmationMotDePasse.type = "password";
//     }
// }
 
// function ContientMajuscule(texte) {
//     return texte.toLocaleLowerCase() !== texte;
// }

// function ContientChiffre(texte) {
//     const expressionReguliere = /\d+/;
//     return texte.match(expressionReguliere) !== null;
// }

// function ValiderMotPasse() {
//     let estValide = false;

//     if (!ContientChiffre(motDePasse.value) || !ContientMajuscule(motDePasse.value)) {
//         motDePasse.classList.add('border-danger');
//         messageErreur.textContent = 'Le mot de passe doit contenir une majuscule et un chiffre. ';
//     } else {
//         motDePasse.classList.remove('border-danger');
//         messageErreur.textContent = '';
//         estValide = true;
//     }

//     return estValide;
// }

// function ValiderConfirmationMotPasse() {
//     let estValide = false;

//     if (motDePasse.value !== confirmationMotDePasse.value) {
//         confirmationMotDePasse.classList.add('border-danger');
//         messageErreur.textContent += 'Les mots de passe doivent être identiques.'
//     } else {
//         confirmationMotDePasse.classList.remove('border-danger');
//         estValide = true;
//     }

//     return estValide;
// }

// function ValiderFormulaire(evenement) {
//     let nbChampsInvalides = 0;

//     if (!ValiderMotPasse()) {
//         ++nbChampsInvalides;
//     }

//     if (!ValiderConfirmationMotPasse()) {
//         ++nbChampsInvalides;
//     }

//     if (nbChampsInvalides !== 0) {
//         messageErreur.classList.remove('d-none');
//         evenement.preventDefault();
//     } else {
//         messageErreur.classList.add('d-none');
//         alert('Formulaire envoyé')
//     }
// } 