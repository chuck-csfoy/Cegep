using Xunit;
using Exercice24;

namespace Exercice24Tests
{
  public class ProgramTests
  {
    [Fact]
    public void FONCTION_DESCRIPTION_RESULTAT_ATTENDU ()
    {

    }
  }
}