﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice25
{
  //1.1
  public class Item
  {
    public string Description { get; set; }
    public int Quantity { get; set; }
    public float UnitPrice { get; set; }
  }
}
