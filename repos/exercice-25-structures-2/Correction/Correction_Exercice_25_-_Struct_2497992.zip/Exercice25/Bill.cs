﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice25
{
  //1.2
  public class Bill
  {
    public string ClientName { get; set; }

    public List<Item> Items { get; set; }
  }
}

