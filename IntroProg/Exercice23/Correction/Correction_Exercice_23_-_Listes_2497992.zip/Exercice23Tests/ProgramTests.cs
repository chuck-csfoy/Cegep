using Xunit;
using Exercice23;

namespace ProgramTests
{
  public class UnitTest1
  {
    [Fact]
    public void FONCTION_DESCRIPTION_RESULTAT_ATTENDU ()
    {
      Program.AskUserInputNumbers();
    }
  }
}